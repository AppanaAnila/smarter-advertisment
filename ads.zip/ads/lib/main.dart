import 'dart:io';

import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:tflite/tflite.dart';
  List<CameraDescription> _cameras;
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  _cameras = await availableCameras();
  runApp(const MyApp());

}

class MyApp extends StatelessWidget {
  
  const MyApp({Key key}) : super(key: key);
  

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  
  const MyHomePage({Key key, @required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
  
}

class _MyHomePageState extends State<MyHomePage> {
  loadModel() async {
    Tflite.close();
    var res=await Tflite.loadModel(
      model: "model/gender_model_unquant.tflite",
      labels: "model/gender_labels.txt",
      numThreads: 1,
      isAsset: true, // defaults to true, set to false to load resources outside assets
      useGpuDelegate: false
    );
    print(res);
  }
   genderfind(File image) async {
    var output = await Tflite.runModelOnImage(
        path: image.path,
        imageMean: 0.0,
        imageStd: 255.0,
        numResults: 2,
        threshold: 0.2,
        asynch: true);
    setState(() {
      print(output[0]['label']);
    });
  }
   CameraController controller;

  @override
    void initState() {
    super.initState();
    loadModel().then((value) {
      print('model loded');
    });

    controller = CameraController(_cameras[0], ResolutionPreset.max);
    controller.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});
    }).catchError((Object e) {
      if (e is CameraException) {
        switch (e.code) {
          case 'CameraAccessDenied':
            print('User denied camera access.');
            break;
          default:
            print('Handle other errors.');
            break;
        }
      }
    });
    
  }
   @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  
  Widget build(BuildContext context) {
    
    return Scaffold(body: Center(child: FloatingActionButton(
  onPressed: () async {
    try {
      final image = await controller.takePicture();
      print(image.path);
      image.saveTo('/Users/divignanesh/Desktop/');
                
              
    } catch (e) {
      print(e);
    }
  },
  child: const Icon(Icons.camera_alt),
)));
  }
}
class DisplayPictureScreen extends StatelessWidget {
  final String imagePath;

  // ignore: use_key_in_widget_constructors
  const DisplayPictureScreen({ @required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Display the Picture')),
      // The image is stored as a file on the device. Use the `Image.file`
      // constructor with the given path to display the image.
      body: Image.file(File(imagePath)),
    );
  }
}
